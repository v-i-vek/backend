import json
import boto3
from botocore.exceptions import ClientError

USER_POOL_ID = 'ap-south-1_lx0p5B3q1'
APP_CLIENT_ID = '4k42k7o35oe36fjvsiidbqammm'


def signin(event, context):
    body = json.loads(event['body'])
    email = body['email']
    password = body['password']

    client = boto3.client('cognito-idp')

    try:
        response = client.initiate_auth(
            AuthFlow='USER_PASSWORD_AUTH',
            AuthParameters={
                'USERNAME': email,
                'PASSWORD': password
            },
            ClientId=APP_CLIENT_ID
        )
        if ['ChallengeName'] == 'NEW_PASSWORD':
            if response['ChallengeName'] == 'NEW_PASSWORD_REQUIRED':
                # User must change their temporary password
                response = client.respond_to_auth_challenge(
                    ClientId=APP_CLIENT_ID,
                    ChallengeName='NEW_PASSWORD_REQUIRED',
                    ChallengeResponses={
                        'USERNAME': email,
                        'NEW_PASSWORD': password
                    },
                    Session=response['Session']
                )

            # Mark the email as verified
            client.admin_update_user_attributes(
                UserPoolId=USER_POOL_ID,
                Username=email,
                UserAttributes=[
                    {'Name': 'email_verified', 'Value': 'true'}
                ]
            )
        else:
            if 'AuthenticationResult' in response:
                access_token = response['AuthenticationResult']['AccessToken']
                id_token = response['AuthenticationResult']['IdToken']

                custom_expiration_time = 43 * 200

                expiration_time = custom_expiration_time

                response_body = {
                'message': 'Signin successful',
                'access_token': access_token,
                'token_id': id_token,
                'expiration_time': expiration_time
            }

            response_headers = {
                'Set-Cookie': f'access_token={access_token}; HttpOnly; Max-Age={expiration_time}',
                'token_id': f'{id_token}; HttpOnly; Max-Age={expiration_time}'
            }

            return {
                'statusCode': 200,
                'body': json.dumps(response_body),
                'headers': response_headers
            }

    except client.exceptions.NotAuthorizedException:
        return {
            'statusCode': 401,
            'body': json.dumps({'message': 'Invalid credentials'})
        }
    except client.exceptions.UserNotFoundException:
        return {
            'statusCode': 404,
            'body': json.dumps({'message': 'User not found'})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': str(e)})
        }

    return {
        'statusCode': 500,
        'body': json.dumps({'message': 'Signin unsuccessful'})
    }
